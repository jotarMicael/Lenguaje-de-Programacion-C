M1
## Comment
# ccc
# ddd
1 6
1.2 3.4 4.5 6.6 56.5 0.0
